# Joint best-justified Q_i reviewer package v2

This package is for an external reviewer who does not have repository access.

## Task

Review whether the current Paper10 best-justified joint-kernel support factors `Q_i` are source-side defensible. This is not an endpoint replay authorization and not cosmological validation.

## What to fill

Fill:

```text
joint_best_justified_qi_reviewer_package_v2/joint_best_justified_qi_review_response_template_v1.csv
```

Allowed `response` values per row:

```text
accept_source_side
accept_with_caveats_source_side
reject
needs_more_context
```

Each completed row must include `reviewer_notes`.

## Forbidden inputs

Do not use endpoint residuals, fit improvements, posterior chains, or post-score control ranks. Keep these fields false in every row:

```text
forbidden_inputs_used=false
endpoint_scores_allowed=false
endpoint_validation_claimed=false
cosmological_validation_claimed=false
```

## Interpretation

A positive response can only support future gate preparation. It cannot authorize a joint likelihood, endpoint replay, cosmological validation, dark-energy explanation, or new-gravity claim.

## Optional local validation

If the reviewer has Python available, place the completed CSV next to this package's files and run the included validator from the repository root or adapt paths as needed:

```bash
python validate_joint_best_justified_qi_review_response_v1.py joint_best_justified_qi_review_response_template_v1.csv
```

The author will run the repository validator after receiving the completed CSV.
