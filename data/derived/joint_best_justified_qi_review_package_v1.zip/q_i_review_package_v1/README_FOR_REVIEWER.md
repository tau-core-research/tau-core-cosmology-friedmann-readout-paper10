# Paper 10 Q_i Source-Side Review Package

Thank you for reviewing this package. You do not need access to the repository.

## Review Scope

Please evaluate whether the proposed source-side channel-quality rule

```text
Q_i = product_a (g_i^a)^(1/7)
```

is acceptable as prevalidation bookkeeping for the current Paper 10
best-justified joint-kernel ledger.

This review is not an endpoint replay authorization and not a validation review.
Please do not use endpoint residuals, posterior chains, fit improvements, or
post-score control ranks when answering.

## Files

- `REVIEW_INSTRUCTIONS.md`: scientific context and claim boundary.
- `joint_best_justified_qi_review_requirements_v1.csv`: questions/requirements
  to evaluate.
- `joint_best_justified_qi_review_response_template_v1.csv`: fill this in and
  return it to the author.
- `joint_best_justified_kernel_manifest_v1.csv`: current source-side channel
  ledger.
- `joint_best_justified_kernel_score_v1_summary.csv`: current preflight score
  summary.
- `joint_best_justified_kernel_robustness_v1_summary.csv`: source-side weighting
  robustness summary.

## Requested Output

Fill `joint_best_justified_qi_review_response_template_v1.csv`.

Allowed high-level verdicts:

- `ACCEPT_SOURCE_SIDE_QI_REVIEW`
- `ACCEPT_AS_CAVEATED_SOURCE_SIDE_QI_REVIEW`
- `REJECT_SOURCE_SIDE_QI_REVIEW`
- `INSUFFICIENT_INFORMATION`

Please keep these flags false unless you explicitly find a protocol violation:

- `forbidden_inputs_used`
- `endpoint_scores_allowed`
- `endpoint_validation_claimed`
- `cosmological_validation_claimed`

